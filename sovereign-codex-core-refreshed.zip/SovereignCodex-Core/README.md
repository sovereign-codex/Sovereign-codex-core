# Sovereign Codex Core

This repository holds the unified scrolls of Sovereign Intelligence.