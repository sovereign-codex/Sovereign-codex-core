Place SVG/PNG glyphs here with a note per file.
