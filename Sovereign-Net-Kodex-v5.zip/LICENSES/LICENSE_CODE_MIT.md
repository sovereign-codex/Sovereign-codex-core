MIT License — standard.
